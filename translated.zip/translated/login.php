<?php
    ob_start();
    session_start();
    include('connection.php');
    if (isset($_POST['submit'])) {
        $user_id = $_POST['userid'];
        $password = $_POST['password'];
        $found = FALSE;
        if ($found == FALSE) {
            $sql = "SELECT * FROM student";
            $result = mysqli_query($conn, $sql);
            while($student = mysqli_fetch_array($result)) {
                if ($student['student_id'] == $user_id && $student["password"] == $password) {
                    $found = TRUE;
                    $_SESSION['user_id'] = $student['student_id'];
                    $_SESSION['nama'] = $student['student_name'];
                    $_SESSION['status'] = 'student';
                    break;
                }
            }
        }
        if ($found == FALSE) {
            $sql = "SELECT * FROM lecturer";
            $result = mysqli_query($conn, $sql);
            while($lecturer = mysqli_fetch_array($result)) {
                if ($lecturer['lecturer_id'] == $user_id && $lecturer["password"] == $password) {
                    $found = TRUE;
                    $_SESSION['user_id'] = $lecturer['lecturer_id'];
                    $_SESSION['nama'] = $lecturer['lecturer_name'];
                    $_SESSION['status'] = 'lecturer';
                    break;
                }
            }
        }
        if ($found == FALSE) {
            $sql = "SELECT * FROM admin";
            $result = mysqli_query($conn, $sql);
            while($admin = mysqli_fetch_array($result)) {
                if ($admin['admin_id'] == $user_id && $admin['password'] == $password) {
                    $found = TRUE;
                    $_SESSION['user_id'] = $admin['admin_id'];
                    $_SESSION['nama'] = $admin['admin_name'];
                    $_SESSION['status'] = 'admin';
                    break;
                }
            }
        }
        if ($found == FALSE) {
            $sql = "SELECT * FROM supervisor";
            $result = mysqli_query($conn, $sql);
            while($supervisor = mysqli_fetch_array($result)) {
                if ($supervisor['supervisor_id'] == $user_id && $supervisor["password"] == $password) {
                    $found = TRUE;
                    $_SESSION['user_id'] = $student['supervisor_id'];
                    $_SESSION['nama'] = $student['supervisor_name'];
                    $_SESSION['status'] = 'supervisor';
                    break;
                }
            }
        }
        if ($found == TRUE) {
            if ($_SESSION['status'] == 'student')
                header("Location: peserta_home.php");
            else if ($_SESSION['status'] == 'lecturer')
                header("Location: hakim_home.php");
            else if ($_SESSION['status'] == 'admin')
                header("Location: urusetia_home.php");
            else if ($_SESSION['status'] == 'supervisor')
                header("Location: guru_home.php");
        }
        else
            echo " <script>
                  alert('Invalid Username or Password');
                   window.location='report_select.php'</script>";
    }
?>

<html>
    <link rel="stylesheet" href="button.css">
    <link rel="stylesheet" href="borang.css">
    <head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>

    <body>
        <center>
            <img src='imej/tajuk1.png'><br>
            <img src='imej/tajuk2.png'>
        </center>
        <h3 class="short">LOG IN</h3>
        <form class="short" action="report_select.php" method="post">
            <table>
            <tr>
                <td><img src="imej/user.png"></td>
                <td>
                <input type="text" name="user_id" placeholder="user_id"> 
                </td>
            </tr>
            <tr>
                <td><img src="imej/lock.png"></td>
                <td>
                <input type="password" name="password" placeholder="password">
                </td>
            </tr>
            </table>
            <button class="login" type="submit" name="submit">Login</button>
            <button class="signup" type="button" onclick="window.location='senarai2.css'">Sign Up</button>
        </form>
    </body>
</html>