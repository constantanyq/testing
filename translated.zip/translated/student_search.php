<?php
	include("admin_menu.php");
	include ('connection.php');
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">

<h3 class="medium">SEARCH</h3>
<form class="medium" action="student_search2.php" method="post">
<table>
	<tr>
		<td>Student Name</td>
		<td>
			<select name="student_id">
				<?php
					$sql = "select * from student";
					$data = mysqli_query($conn, $sql);
					while ($student = mysqli_fetch_array($data)) {
						echo "<option value='$student[student_id]'>$student[student_id]:
					$student[student_name]</option>";
				} 
			?>
		</select>
	</td>
	</tr>
</table>
<button class="search" type="submit">Search</button>
</form>
