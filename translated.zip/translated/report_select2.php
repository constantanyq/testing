<?php
    include("admin_menu.php");
    include('connection.php');
?>

<html>
    <link rel="stylesheet" href="borang.css">
    <link rel="stylesheet" href="button.css">

    <head>
        <style>
            /*background image for page*/
            body {
               background-image: url(imej/wood8.png);
               background-repeat: no-repeat;
               background-size: cover;
               background-attachment: fixed;
                 }
        </style>
    </head>
    
<!sistem bagi pemilihan laporan jenis keseluruhan atau mengikut lecturer>
    <body>
        <h3 class = "short">REPORT TYPE SELECTION</h3>
        <form class = "short" action="laporan_print.php" method="post">
            <select id='choice' name='pilihan' onchange='show_selection()'>
            <option value=1>Overall List</option>
            <option value=2>List by Lecturer</option>
            <option value=3>List by Supervisor</option>
                </select> <br>
                <div id="lecturer" style="display:none">
                <select name="lecturer_id">
                <?php
                    include('connection.php');
                    $sql = "select * from lecturer";
                    $data = mysqli_query($conn, $sql);
                    while ($lecturer = mysqli_fetch_array($data)) {
                        echo "<option value='$lecturer[lecturer_id]'>$lecturer[lecturer_name]>$lecturer[lecturer_email]</option>";
                    }
                ?>
                </select> <br>
                <div id="supervisor" style="display:none">
                <select name="supervisor_id">
                <?php
                    include('connection.php');
                    $sql = "select * from supervisor";
                    $data = mysqli_query($conn, $sql);
                    while ($supervisor = mysqli_fetch_array($data)) {
                        echo "<option value='$supervisor[supervisor_id]'>$supervisor[supervisor_name]>$supervisor[supervisor_email]</option>";
                    }
                ?>
                </select>
                </div>

            <button class="view" type="submit">View</button>
        </form>
<script>
    function show_selection () {
        var selection = document.getElementById("choice").value;
        if (selection == 1) {
            document.getElementById('lecturer').style.display = 'none';
            document.getElementById('supervisor').style.display = 'none';
        }
        else if (selection == 2) {
            document.getElementById('lecturer').style.display = 'block'; 
            document.getElementById('supervisor').style.display = 'none';
        }
        else if (selection == 3) {
            document.getElementById('lecturer').style.display = 'none'; 
            document.getElementById('supervisor').style.display = 'block';
        }
        else if (selection == 4) {
            document.getElementById('lecturer').style.display = 'block';
            document.getElementById('supervisor').style.display = 'block';
        }
    }
</script>
</body>
</html>