<?php
    include("supervisor_add_form.php");
    include("lecturer_update_form.php");
?>
