<link rel="stylesheet" href="menu.css">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 120px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
</head>

<?php
	include("lecturer_add_form.php");
    include("connection.php");

	$student_id = $_POST["student_id"];
	$total_marks = $_POST["total_marks"];
	
	$sql = "select * from component";
	$data = mysqli_query($conn, $sql);

	while ($component = mysqli_fetch_array($data)) {
		$component_marks = $_POST["$component[component_id]"];
		$component_id = $component['component_id'];
		$sql = "insert into result values('$student_id', '$component_id', '$component_marks', '$total_marks')";
		$result = mysqli_query($conn, $sql);


	if ($result == true)
		echo "<br><center>Successfully added</center>";
	else 
		echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	} 
?>
