<?php
      include("supervisor_add_form.php");
      include('connection.php');

      if (isset($_POST["submit"])) {
           $student_id = $_POST["student_id"];
           $password = $_POST["password"];
           $student_name = $_POST["student_name"];
           $email = $_POST["email"];
           $programme = $_POST["programme"];
           $lecturer_id = $_POST["lecturer_id"];
           $admin_id = $_POST["admin_id"];
           $supervisor_id = $_POST["supervisor_id"];
          
           $sql = "insert into student values('$student_id', '$password', '$student_name', '$email', '$programme', '$lecturer_id', '$admin_id', '$supervisor_id')";
          
           $result = mysqli_query($conn, $sql);
           if ($result == true)
                 echo "<br><center>Successfully added</center>";
           else
                 echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
      }  
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css"> 
<link rel="stylesheet" href="menu.css">

<h3 class="medium">ADD STUDENT</h3>
<form class="medium" action="supervisor_student_delete.php" method="post">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 120px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
</head>

     <table>
       <tr>
              <td class="colour">Student ID</td>
	          <td><input type = "text" name = "student_id" 
               placeholder="max: 3 char"></td>
	   </tr>
       <tr>
	           <td class="colour">Password</td>
	           <td><input type="password" name="password" 
               placeholder="max: 8 char"></td>
	   </tr>
          <tr>
               <td class="colour">Student Name</td>
               <td><input type="text" name="student_name"></td>
          </tr>
          <tr>
               <td class="colour">Email</td>
               <td><input type="text" name="email"></td>
          </tr>
          <tr>
               <td class="colour">Programme</td>
               <td><input type="text" name="programme"></td>
          </tr>

          <tr>
               <td class="colour">Lecturer Name</td>
               <td> <select name="lecturer_id">
                    <?php
                          $sql = "select * from lecturer";
                          $data = mysqli_query($conn, $sql);
                          while ($lecturer = mysqli_fetch_array($data)) {
                                echo "<option value='$lecturer[lecturer_id]'>$lecturer[lecturer_name]>$lecturer[lecturer_email]</option>";
                          }
                    ?>
                    </select>
               </td>
          </tr>
	<tr>
		<td class="colour">Admin Name</td>
		<td> <select name="admin_id">
			<?php
				$sql = "select * from admin";
				$data = mysqli_query($conn, $sql);
				while ($admin = mysqli_fetch_array($data)) {
				echo "<option value='$admin[admin_id]'>$admin[admin_name]</option>";
				}
			?>
			</select>
		</td>
	</tr>
         	<tr>
		<td class="colour">Supervisor Name</td>
		<td> <select name="supervisor_id">
			<?php
				$sql = "select * from supervisor" ;
				$data = mysqli_query($conn, $sql);
				while ($supervisor = mysqli_fetch_array($data)) {
				echo "<option value='$supervisor[supervisor_id]'>$supervisor[supervisor_name]>$supervisor[supervisor_email]</option>";
				}
			?>
			</select>
		</td>
	</tr>
</table>
	<button class="add" type="submit" name="submit">Add</button>
</form>
<br>

<center>
	<button class="blue" onclick="change_colour(0)">Biru</button>
	<button class="green" onclick="change_colour(1)">Hijau</button>
	<button class="red" onclick="change_colour(2)">Merah</button>
	<button class="black" onclick="change_colour(3)">Hitam</button>
</center>

<script>
	function change_colour(n){
		var colours = ["Blue", "Green", "Red", "Black"];
		var teks = document.getElementsByClassName("colour");
		for(var i=0; i<teks.length; i++)
			teks[i].style.color=colours[n];
	}
</script>