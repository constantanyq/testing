<?php
	include("admin_menu.php");
    include("connection.php");
?>

<link rel="stylesheet" href="senarai.css">
<link rel="stylesheet" href="borang.css">
<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>

<table>
	<caption>SUPERVISOR LIST</caption>
	<tr>
		<th>ID</th>
		<th>Name</th>		
		<th>Password</th>
        <th>Programme</th>
        <th>Kategori</th>
		<th colspan="2">Action</th>
	</tr>

<?php
	$sql = "select * from supervisor";
	$result = mysqli_query($conn, $sql);
	while($supervisor = mysqli_fetch_array($result)) {
		echo "<tr>
			<td>$supervisor[supervisor_id]</td>
			<td>$supervisor[supervisor_name]</td>
			<td>$supervisor[password]</td>
            <td>$supervisor[programme]</td>
            <td>$supervisor[supervisor_email]</td>
			<td><a href='supervisor_update_form.php?supervisor_id=$supervisor[supervisor_id]'>update</a></td>
			<td><a href='supervisor_delete.php?supervisor_id=$supervisor[supervisor_id]'>delete</a></td>
		</tr>";
}
?>
</table>