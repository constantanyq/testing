<?php
	include("supervisor_add_form.php");
    include('connection.php');
?>

<link rel="stylesheet" href="senarai.css">
<link rel="stylesheet" href="menu.css">
<link rel="stylesheet" href="borang.css">

<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 120px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>

<table>
<caption>STUDENT LIST</caption>
<tr>
<th>Student ID</th>
<th>Student Name</th>
<th>Password</th>
<th>Email</th>
<th>Programme</th>
<th>Lecturer ID</th>
<th>Supervisor ID</th>
</tr>

<?php
$sql = "select * from student";
$result = mysqli_query($conn, $sql);
while($student = mysqli_fetch_array($result)) {
echo "<tr> 
<td>$student[student_id]</td>
<td class='name'>$student[student_name]</td>
<td>$student[password]</td>
<td>$student[email]</td>
<td>$student[programme]</td>
<td>$student[lecturer_id]</td>
<td>$student[supervisor_id]</td>
</tr>";
}
?>
</table>

