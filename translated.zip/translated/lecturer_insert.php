<?php
    include("lecturer_add_form.php");
    include("lecturer_update_form.php");
?>
