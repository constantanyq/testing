<?php
      include("admin_menu.php");
      include("connection.php");
?>

<link rel="stylesheet" href="senarai.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>
<table>
      <caption>COMPONENT LIST</caption>
      <tr>
           <th>Component ID</th>
           <th>Component</th>
           <th>Weightage</th>
           <th colspan="2">Action</th>
      </tr>
      <?php
            $sql = "select * from component";
            $result = mysqli_query($conn, $sql);
            while($component = mysqli_fetch_array($result)) {
                  echo "<tr> <td>$component[component_id]</td>
                         <td>$component[component_name]</td>
                         <td>$component[component_weightage]</td>
                         <td><a href='component_update_form.php?component_id=$component[component_id]'>update</a></td>
                         <td><a href='component_delete.php?component_id=$component[component_id]'>delete</a></td>
            </tr>";
            }
      ?>
</table>
