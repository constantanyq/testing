<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$supervisor_id = $_POST["supervisor_id"];
		$supervisor_name = $_POST["supervisor_name"];
		$password = $_POST["password"];
        $supervisor_email = $_POST["supervisor_email"];
        $programme = $_POST["programme"];

		$sql = "insert into supervisor values('$supervisor_id', '$supervisor_name', '$password', '$supervisor_email', '$programme')";

		$result = mysqli_query($conn, $sql);
		if ($result == true)
			echo "<br><center>Successfully added</center>";
		else
			echo "<br><center>Please enter valid information.</center>";
	}
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<link rel="stylesheet" href="menu.css">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 90px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
</head>

<h3 class="medium">ADD SUPERVISOR</h3>
<form class="medium" action="supervisor_insert.php" method="post">
	<table>
       <tr>
	       <td>Supervisor ID</td>
	       <td><input type="text" name="supervisor_id" 
               placeholder="max: 3 char"></td>
	   </tr>
		<tr>
			<td>Supervisor Name</td>
			<td><input type="text" name="supervisor_name"></td>
		</tr>
	   <tr>
	       <td>Password</td>
	       <td><input type="password" name="password" 
               placeholder="max: 8 char"></td>
	   </tr>

        <tr>
			<td>Supervisor Email</td>
             <td><input type="text" name="supervisor_email"></td>
		</tr>
        <tr>
			<td>Programme</td>
			<td><input type="text" name="programme"></td>
		</tr>
	</table>
        <button class="add" type="submit" name="submit">Add</button>
</form>

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        
        button.add{
             background-image: url(imej/add.png);
             background-repeat: no-repeat;
             background-position: 6px ;

        }
    </style>
</head>


<center>
	<button class="blue" onclick="change_colour(0)">Biru</button>
	<button class="green" onclick="change_colour(1)">Hijau</button>
	<button class="red" onclick="change_colour(2)">Merah</button>
	<button class="black" onclick="change_colour(3)">Hitam</button>
</center>

<script>
	function change_colour(n){
		var colours = ["Blue", "Green", "Red", "Black"];
		var teks = document.getElementsByClassName("colour");
		for(var i=0; i<teks.length; i++)
			teks[i].style.color=colours[n];
	}
</script>

