<?php
	include("admin_menu.php");
    include("connection.php");


	if (isset($_POST["submit"])) {
		$admin_id = $_POST["admin_id"];
		$sql = "delete from admin where admin_id = '$admin_id' ";
		$result = mysqli_query($conn, $sql);

		if ($result == true) {
			$record_count = mysqli_affected_rows($conn);
			if ($record_count > 0)
				echo "<br><center>Successfully deleted</center>";
			else
				echo "Tidak Successfully deleted. Rekod tidak ada dalam jadual";
		}
	else
		echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}

	if (isset($_GET['admin_id']))
		$admin_id = $_GET['admin_id'];
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<link rel="stylesheet" href="menu.css">

<h3 class="medium">DELETE ADMIN</h3>
<form class="medium" action="admin_delete.php" method="post">

<table>
	<tr>
		<td>
        Admin ID
        </td>
        <td><input type="text" name="admin_id" value = "<?php echo $admin_id; ?>" ></td>
	</tr>
</table>

<button class="delete" type="submit" name="submit">Delete</button>
</form>
