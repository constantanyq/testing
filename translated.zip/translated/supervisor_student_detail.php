<?php
	include("supervisor_add_form.php");
    include("connection.php");

    $student_id = $_POST['student_id'];
	
	$sql = "select * from student where student_id = '$student_id'";
	$result = mysqli_query($conn, $sql);
	$student = mysqli_fetch_array($result);

	$student_name = $student['student_name'];
	$email = $student['email'];
	$programme = $student['programme'];
	$password = $student['password'];
	$lecturer_id = $student['lecturer_id'];
    $supervisor_id = $student['supervisor_id']
?>

<link rel = "stylesheet" href = "senarai.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>

<table>
	<caption >STUDENT INFORMATION</caption>
	<tr>
		<th>Item</th>
		<th>Information</th>
	</tr>
	<tr>
		<td class="result">Student ID</td>
		<td class="result"><?php echo $student_id; ?></td>
	</tr>
	<tr>
		<td class="result">Student Name</td>
		<td class="result"><?php echo $student_name; ?></td>
	</tr>
<tr>
		<td class="result">Email</td>
		<td class="result"><?php echo $email; ?></td>
	</tr>
<tr>
		<td class="result">Programme</td>
		<td class="result"><?php echo $programme; ?></td>
	</tr>
<tr>
		<td class="result">Password</td>
		<td class="result"><?php echo $password; ?></td>
	</tr>
</table>
<?
    $ranking = 0;
	$sql = "select * from result
		join student on result.student_id = student.student_id
		join component on result.component_id = component.component_id
		join lecturer on student.lecturer_id = lecturer.lecturer_id
		group by student.student_id order by result.total_marks desc";

	$data = mysqli_query($conn, $sql);
	$count = 0;
	while ($result = mysqli_fetch_array($data)) {
		$count = $count + 1;
		if ($result['student_id'] == $student_id)
			$ranking = $count;
	}// end while
?>

<link rel="stylesheet" href="senarai.css">

<table>
	<caption>STUDENT MARKS</caption>
	<tr>
		<th>Component Name</th>
		<th>Weightage</th>
		<th>Marks Obtained</th>
	</tr>
	<?php
		$sql = "select * from result
			join component on result.component_id = component.component_id
			where student_id = '$student_id' ";
		$data = mysqli_query($conn, $sql);
		$record_count = mysqli_num_rows($data);
		if ($record_count > 0) {
			while ($result = mysqli_fetch_array($data)) {
				echo "<tr >
					<td>$result[component_name]</td>
					<td>$result[component_weightage]</td>
					<td>$result[component_marks]</td>
					</tr>";
				$total_marks = $result['total_marks'];
			}
			echo "<tr class='marks_total'> <td ></td>
				<td class='marks_total'>Total Marks</td>
				<td>$total_marks</td>
				</tr>";
			if ($ranking !=0)
				echo "<tr class='marks_total'> <td ></td>
				<td class='marks_total'>Ranking</td>
				<td>$ranking/$count</td>
				</tr></table>";
		}
		else {
			echo "<tr > <td>component_marks</td> <td>belum</td> <td>dinilai</td>
				</tr></table>";
		}

?>
