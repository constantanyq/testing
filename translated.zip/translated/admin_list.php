<?php
      include("admin_menu.php");
      include ('connection.php');
?>

<link rel="stylesheet" href="senarai.css">
<link rel="stylesheet" href="menu.css">
<link rel="stylesheet" href="borang.css">

<table>
     <caption>ADMIN LIST</caption>
     <tr>
           <th>ID</th>
           <th>Name</th>
           <th>Password</th>
           <th colspan="2">Action</th>
     </tr>

     <?php
           $sql = "select * from admin";
           $result = mysqli_query($conn,$sql);
           while($admin = mysqli_fetch_array($result)) {
              echo "<tr> <td>$admin[admin_id]</td>
              <td>$admin[admin_name]</td>
              <td>$admin[password]</td>
              <td><a href= 'admin_update.php?admin_id=$admin[admin_id]'>update</a></td>
              <td><a href= 'admin_delete.php?admin_id=$admin[admin_id]'>delete</a></td>
              </tr>";
            }
     ?>
</table>
