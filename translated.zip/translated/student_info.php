<?php
	include("admin_menu.php");
    include("connection.php");
	
	$student_id = $_POST['student_id'];
	
	$sql = "select * from student where student_id = '$student_id'";
	$result = mysqli_query($conn, $sql);
	$student = mysqli_fetch_array($result);

	$student_name = $student['student_name'];
	$email = $student['email'];
	$programme = $student['programme'];
	$password = $student['password'];
	$lecturer_id = $student['lecturer_id'];
    $supervisor_id = $student['supervisor_id']
?>

<link rel = "stylesheet" href = "senarai.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>

<table>
	<caption >STUDENT INFORMATION</caption>
	<tr>
		<th>Item</th>
		<th>Information</th>
	</tr>
	<tr>
		<td class="result">Student ID</td>
		<td class="result"><?php echo $student_id; ?></td>
	</tr>
	<tr>
		<td class="result">Student Name</td>
		<td class="result"><?php echo $student_name; ?></td>
	</tr>
<tr>
		<td class="result">Email</td>
		<td class="result"><?php echo $email; ?></td>
	</tr>
<tr>
		<td class="result">Programme</td>
		<td class="result"><?php echo $programme; ?></td>
	</tr>
<tr>
		<td class="result">Password</td>
		<td class="result"><?php echo $password; ?></td>
	</tr>
<tr>
		<td class="result">Lecturer ID</td>
		<td class="result"><?php echo $lecturer_id; ?></td>
	</tr>
<tr>
		<td class="result">Supervisor ID</td>
		<td class="result"><?php echo $supervisor_id; ?></td>
	</tr>
</table>
