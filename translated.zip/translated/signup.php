<?php
   include('connection.php');
/*Menentukan elemen-elemen yang diperlukan dan memasukkan data yang berkenaan dalam sistem*/
      if (isset($_POST["submit"])) {
           $student_id = $_POST["student_id"];
           $password = $_POST["password"];
           $student_name = $_POST["student_name"];
           $email = $_POST["email"];
           $programme = $_POST["programme"];
           $lecturer_id = $_POST["lecturer_id"];
           $admin_id = $_POST["admin_id"];
           $supervisor_id = $_POST["supervisor_id"];

        $sql = "insert into student values('$student_id', '$password', '$student_name', '$email', '$programme', '$lecturer_id', '$admin_id', '$supervisor_id')";
          
        $result = mysqli_query($conn, $sql);
       /*System alert*/
        if ($result)
            echo "<script>alert('Sign up successful')</script>";
        else
            echo "<script>alert('Sign up failed')</script>";
        echo "<script>window.location='report_select.php'</script>";
   }
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<head>
    <style>
        /*background image*/
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        /*button add dan hiasan bagi tulisan dan borang*/
        button {
             font-family: verdana;
             font-weight: bold;
             font-size: 11px;

             background-color: #CCCCFF; 
             padding: 4px 6px 4px 32px;
             border: ridge;
             border-radius: 7px;
             border-width: thick;
             border-color: aliceblue;
             color: black;
             margin-top: 30px;
             padding: 8px 30px;
             text-align: center;
             text-decoration: underline;
             display: inline-block;
             font-size: 14px;
             
        }
        
        button.add{
             background-image: url(imej/add.png);
             background-repeat: no-repeat;
             background-position: 6px ;

        }
    </style>
</head>

<body>
   <center>
      <img src='imej/tajuk1.png'><br>
      <img src='imej/tajuk2.png'>
   </center>

   <h3 class="medium">SIGN UP</h3>
   <form class="medium" action="senarai2.css" method="post">
      <table>
          <!elemen bagi borang Sign Up>
        <tr>
              <td class="colour">Student ID</td>
	          <td><input type = "text" name = "student_id" 
               placeholder="max: 3 char"></td>
	   </tr>
       <tr>
	           <td class="colour">Password</td>
	           <td><input type="password" name="password" 
               placeholder="max: 8 char"></td>
	   </tr>
          <tr>
               <td class="colour">Student Name</td>
               <td><input type="text" name="student_name"></td>
          </tr>
          <tr>
               <td class="colour">Email</td>
               <td><input type="text" name="email"></td>
          </tr>
          <tr>
               <td class="colour">Programme</td>
               <td><input type="text" name="programme"></td>
          </tr>

          <tr>
               <td class="colour">Lecturer Name</td>
               <td> <select name="lecturer_id">
                    <?php
                          $sql = "select * from lecturer";
                          $data = mysqli_query($conn, $sql);
                          while ($lecturer = mysqli_fetch_array($data)) {
                                echo "<option value='$lecturer[lecturer_id]'>$lecturer[lecturer_name]>$lecturer[lecturer_email]</option>";
                          }
                    ?>
                    </select>
               </td>
          </tr>
	<tr>
		<td class="colour">Admin Name</td>
		<td> <select name="admin_id">
			<?php
				$sql = "select * from admin";
				$data = mysqli_query($conn, $sql);
				while ($admin = mysqli_fetch_array($data)) {
				echo "<option value='$admin[admin_id]'>$admin[admin_name]</option>";
				}
			?>
			</select>
		</td>
	</tr>
         	<tr>
		<td class="colour">Supervisor Name</td>
		<td> <select name="supervisor_id">
			<?php
				$sql = "select * from supervisor" ;
				$data = mysqli_query($conn, $sql);
				while ($supervisor = mysqli_fetch_array($data)) {
				echo "<option value='$supervisor[supervisor_id]'>$supervisor[supervisor_name]>$supervisor[supervisor_email]</option>";
				}
			?>
			</select>
		</td>
	</tr>
    </table>
    <button class="add" type="submit" name="submit">Register</button>
    <button class="delete" type="button" onclick="window.location='report_select.php'">Cancel</button>
</form>
</body>
