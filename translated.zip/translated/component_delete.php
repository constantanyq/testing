<?php
    include("admin_menu.php");
    include("connection.php");
    if (isset($_POST["submit"])) {
        $component_id = $_POST["component_id"];
        $sql = "delete from component where component_id = '$component_id' ";
        $result = mysqli_query($conn, $sql);
        if ($result == true) {
            $record_count = mysqli_affected_rows($conn);
            if ($record_count > 0)
                echo "<br><center>Successfully deleted</center>";

            else
                echo "Tidak Successfully deleted. Rekod tidak ada dalam jadual";
        }
        else
            echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
    }
    if (isset($_GET['component_id']))
        $component_id = $_GET['component_id'];
?>
<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<h3 class="medium">DELETE COMPONENT</h3>
<form class="medium" action="component_menu_css.php" method="post">
    <table>
    <tr>
        <td>Component ID</td>
        <td><input type="text" name="component_id" value = "<?php echo $component_id; ?>" ></td>
    </tr>
    </table>
    <button class="delete" type="submit" name="submit">Delete</button>
</form>
