<?php
	include("supervisor_add_form.php");
	include ('connection.php');
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">

<h3 class="medium">SEARCH</h3>
<form class="medium" action="supervisor_student_detail.php" method="post">
<table>
	<tr>
        <td>Supervisor Name : </td>
        <td><?php echo $name; ?> </td>
		<td>Student Name</td>
		<td>
			<select name="student_id">
				<?php
					$sql = "select * from student";
					$data = mysqli_query($conn, $sql);
					while ($student = mysqli_fetch_array($data)) {
						echo "<option value='$student[student_id]'>$student[student_id]:
					$student[student_name]</option>";
				} 
			?>
		</select>
	</td>
	</tr>
</table>
<button class="search" type="submit">Search</button>
</form>
