<?php
    include("admin_menu.php");
    include('connection.php');
?>

<html>
    <link rel="stylesheet" href="borang.css">
    <link rel="stylesheet" href="button.css">

    <head>
        <style>
            /*background image for page*/
            body {
               background-image: url(imej/wood8.png);
               background-repeat: no-repeat;
               background-size: cover;
               background-attachment: fixed;
                 }
        </style>
    </head>
    
<!sistem bagi pemilihan laporan jenis keseluruhan atau mengikut lecturer>
    <body>
        <!tajuk jadual>
        <h3 class = "short">REPORT TYPE SELECTION</h3>
        <form class = "short" action="laporan_print.php" method="post">
            <select id='choice' name='pilihan' onchange='show_selection()'>
                <!Scroll down menu>
            <option value=1>Overall List</option>
            <option value=2>List by Lecturer</option>
                </select> <br>
                <div id="lecturer" style="display:none">
                <select name="lecturer_id">
                <?php
                    include('connection.php');
                    $sql = "select * from lecturer";
                    $data = mysqli_query($conn, $sql);
                    while ($lecturer = mysqli_fetch_array($data)) {
                        echo "<option value='$lecturer[lecturer_id]'>$lecturer[lecturer_name]>$lecturer[lecturer_email]</option>";
                    }
                ?>
                </select>
                </div>
            <!butang-buatng>
            <button class="view" type="submit">View</button>
        </form>
        
<!pemilihan jenis laporan sama ada mengikut lecturer atau tidak>
<script>
    function show_selection () {
        var selection = document.getElementById("choice").value;
        if (selection == 1) {
            document.getElementById('lecturer').style.display = 'none';

        }
        else if (selection == 2) {
            document.getElementById('lecturer').style.display = 'block';
        }
    }
</script>
</body>
</html>
