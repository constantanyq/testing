<link rel="stylesheet" href="menu.css">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 120px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
</head>

<body>
    <div class="menu">
	<div class="supervisor">
		<h2>e-INTERNSHIP MANAGEMENT SYSTEM</h2>
		<ul>
			<li> <a href="supervisor_delete.php"> <b>HOME</b></a> </li>
		</ul>
		<ul>
			<li> <a href="#"> <b>STUDENT</b></a>
				<ul>
					<li><a href="supervisor_student_delete.php">Add</a></li>
                    <li><a href="supervisor_student_list.php">View</a></li>
				</ul>
			</li>
		</ul>
        <ul>
			<li> <a href="#"> <b>SUPERVISOR</b></a>
				<ul>
                    <li><a href="supervisor_list.php">View</a></li>
				</ul>
			</li>
		</ul>
		<ul>
			<li> <a href="login.php"> <b>LOGOUT</b></a> </li>
		</ul>
	</div>
</div>
</body>
