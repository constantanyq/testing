<link rel="stylesheet" href="menu.css">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 150px;
        padding: 10px;
        border: none;
        margin: 0px;
        background-color: gainsboro;

	display: block;
	text-decoration: none;
}
    </style>
</body>
</head>
<body>
	<div class="menu">
	<div class="student">
        
		<h2>e-INTERNSHIP MANAGEMENT SYSTEM</h2>
		<ul>
			<li> <a href="student_delete.php"> <b>HOME</b></a> </li>
		</ul>
		<ul>
			<li> <a href="#"> <b>MARKS</b></a>
				<ul>
					<li><a href="student_add_form.php">View</a></li>
				</ul>
			</li>
		</ul>
        

<ul>
	<li> <a href="login.php"> <b>LOGOUT</b></a> </li>
</ul>
</div>
</div>
</body>
