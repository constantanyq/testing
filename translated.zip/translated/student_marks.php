<?php
	session_start();
	include("student_marks.php");
    include("connection.php");

	$name = $_SESSION["nama"];
	$student_id = $_SESSION['user_id'];

	$ranking = 0;
	$sql = "select * from result
		join student on result.student_id = student.student_id
		join component on result.component_id = component.component_id
		join lecturer on student.lecturer_id = lecturer.lecturer_id
		group by student.student_id order by result.total_marks desc";

	$data = mysqli_query($conn, $sql);
	$count = 0;
	while ($result = mysqli_fetch_array($data)) {
		$count = $count + 1;
		if ($result['student_id'] == $student_id)
			$ranking = $count;
	}// end while
?>

<link rel="stylesheet" href="senarai.css">

<head>
    <style>
        body {
            background-image: url(imej/wood5.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        
        ul li a {
	        font-family: verdana;
	        font-size: 14px;
	        font-weight: normal;
	        text-align: center;
            color: black;

	width: 150px;
        padding: 10px;
        border: none;
        margin: 0px;
        background-color: gainsboro;

	display: block;
	text-decoration: none;
}
    </style>
</head>

<table>
	<caption>Student Name : <?php echo $name ?></caption>
	<tr>
		<th>Component Name</th>
		<th>Weightage</th>
		<th>Marks Obtained</th>
	</tr>
	<?php
		$sql = "select * from result
			join component on result.component_id = component.component_id
			where student_id = '$student_id' ";
		$data = mysqli_query($conn, $sql);
		$record_count = mysqli_num_rows($data);
		if ($record_count > 0) {
			while ($result = mysqli_fetch_array($data)) {
				echo "<tr >
					<td>$result[component_name]</td>
					<td>$result[component_weightage]</td>
					<td>$result[component_marks]</td>
					</tr>";
				$total_marks = $result['total_marks'];
			}
			echo "<tr class='marks_total'> <td ></td>
				<td class='marks_total'>Total Marks</td>
				<td>$total_marks</td>
				</tr>";
			if ($ranking != 0)
				echo "<tr class='marks_total'> <td ></td>
				<td class='marks_total'>Ranking</td>
				<td>$ranking/$count</td>
				</tr></table>";
		}
		else {
			echo "<tr > <td>component_marks</td> <td>belum</td> <td>dinilai</td>
				</tr></table>";
		}

?>
