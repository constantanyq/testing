<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$supervisor_id = $_POST["supervisor_id"];
		$password = $_POST["password"];
		$supervisor_name = $_POST["supervisor_name"];
        $supervisor_email = $_POST["supervisor_email"];
        $programme = $_POST["programme"];

		$sql = "update supervisor set password='$password', supervisor_name = '$supervisor_name', supervisor_email = '$supervisor_email', programme = '$programme' where supervisor_id = '$supervisor_id' ";

		$result = mysqli_query($conn, $sql);
		if ($result == true)
			echo "<br><center>Successfully updated</center>";
		else
			echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}

	if (isset($_GET['supervisor_id']))
		$supervisor_id = $_GET['supervisor_id'];

	$sql = "select * from supervisor where supervisor_id = '$supervisor_id' ";
	$result = mysqli_query($conn, $sql);
	while($supervisor = mysqli_fetch_array($result)) {
		$password = $supervisor['password'];
		$supervisor_name = $supervisor['supervisor_name'];
        $supervisor_email = $supervisor['supervisor_email'];
        $programme = $supervisor['programme'];
	}
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
               button.update{
             background-image: url(imej/update.png);
             background-repeat: no-repeat;
             background-position: 6px ;

        }
    </style>
</head>

<h3 class="medium">UPDATE SUPERVISOR</h3>
<form class="medium" action="supervisor_view.php" method="post">
	<table>
<tr>
       <tr>
	       <td>Supervisor ID</td>
	       <td><input type="text" name="supervisor_id" value= "<?php echo $supervisor_id; ?>"
               placeholder="max: 3 char"></td>
	   </tr>
	   <tr>
	       <td>Password</td>
	       <td><input type="password" name="password" value= "<?php echo $password; ?>"
               placeholder="max: 8 char"></td>
	   </tr>

		<tr>
			<td>Supervisor Name</td>
			<td><input type="text" name="supervisor_name" value= "<?php echo $supervisor_name; ?>"></td>
		</tr>
        <tr>
			<td>Supervisor Email</td>
             <td><input type="text" name="supervisor_email" value= "<?php echo $supervisor_email; ?>"></td>
		</tr>
        <tr>
			<td>Programme</td>
             <td><input type="text" name="programme" value= "<?php echo $programme; ?>"></td>
		</tr>
	</table>
	<button class="update" type="submit" name="submit">Update</button>
</form>
