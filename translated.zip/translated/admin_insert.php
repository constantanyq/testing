<?php
    include("admin_menu.php");
	include("connection.php");

	if (isset($_POST["submit"])) {
		$admin_id = $_POST["admin_id"];
		$password = $_POST["password"];
		$admin_name = $_POST["admin_name"];

		$sql = "insert into admin values('$admin_id', '$password', '$admin_name')";
		$result = mysqli_query($conn, $sql);
		if ($result == true)
				echo "Successfully added";
		else
				echo "Error: $sql<br>".mysqli_error($conn);
	}
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<link rel="stylesheet" href="menu.css">

<h3 class="medium">ADD ADMIN</h3>
<form class="medium" action="admin_insert.php" method="post">
    <table>

	   <tr>
	       <td>Admin ID</td>
	       <td><input type="text" name="admin_id" 
               placeholder="max: 3 char"></td>
	   </tr>

	   <tr>
	       <td>Admin Name</td>
	       <td><input type="text" name="admin_name"></td>
	   </tr>

	   <tr>
	       <td>Password</td>
	       <td><input type="password" name="password" 
               placeholder="max: 8 char"></td>
	   </tr>

    </table>
    <button class="add" type="submit" 
            name="submit">Add</button>
</form>

<center>
	<button class="blue" onclick="change_colour(0)">Biru</button>
	<button class="green" onclick="change_colour(1)">Hijau</button>
	<button class="red" onclick="change_colour(2)">Merah</button>
	<button class="black" onclick="change_colour(3)">Hitam</button>
</center>

<script>
	function change_colour(n){
		var colours = ["Blue", "Green", "Red", "Black"];
		var teks = document.getElementsByClassName("colour");
		for(var i=0; i<teks.length; i++)
			teks[i].style.color=colours[n];
	}
</script>

