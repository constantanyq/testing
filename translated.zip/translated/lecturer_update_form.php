<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$lecturer_id = $_POST["lecturer_id"];
		$password = $_POST["password"];
		$lecturer_name = $_POST["lecturer_name"];
        $lecturer_email = $_POST["lecturer_email"];

		$sql = "update lecturer set password='$password', lecturer_name = '$lecturer_name', lecturer_email = '$lecturer_email' where lecturer_id = '$lecturer_id' ";

		$result = mysqli_query($conn, $sql);
		if ($result == true)
			echo "<br><center>Successfully updated</center>";
		else
			echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}

	if (isset($_GET['lecturer_id']))
		$lecturer_id = $_GET['lecturer_id'];

	$sql = "select * from lecturer where lecturer_id = '$lecturer_id' ";
	$result = mysqli_query($conn, $sql);
	while($lecturer = mysqli_fetch_array($result)) {
		$password = $lecturer['password'];
		$lecturer_name = $lecturer['lecturer_name'];
        $lecturer_email = $lecturer['lecturer_email'];
	}
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
               button.update{
             background-image: url(imej/update.png);
             background-repeat: no-repeat;
             background-position: 6px ;

        }
    </style>
</head>

<h3 class="medium">UPDATE LECTURER</h3>
<form class="medium" action="lecturer_list.php" method="post">
	<table>
<tr>
       <tr>
	       <td>Lecturer ID</td>
	       <td><input type="text" name="lecturer_id" value= "<?php echo $lecturer_id; ?>"
               placeholder="max: 3 char"></td>
	   </tr>
	   <tr>
	       <td>Password</td>
	       <td><input type="password" name="password" value= "<?php echo $password; ?>"
               placeholder="max: 8 char"></td>
	   </tr>

		<tr>
			<td>Lecturer Name</td>
			<td><input type="text" name="lecturer_name" value= "<?php echo $lecturer_name; ?>"></td>
		</tr>
        <tr>
			<td>Lecturer Email</td>
             <td><input type="text" name="lecturer_email" value= "<?php echo $lecturer_email; ?>"></td>
		</tr>
	</table>
	<button class="update" type="submit" name="submit">Update</button>
</form>
