<link rel="stylesheet" href="menu.css">

<body>
<div class="menu">
    <div class="admin">
        <h2>e-INTERNSHIP MANAGEMENT SYSTEM</h2>
        <ul>
            <li><a href="#"> <b>COMPONENT</b></a>
                <ul>
                    <li><a href="component_delete.php">Add</a></li>
                    <li><a href="component_add_form.php">List</a></li>
                </ul>
            </li>
        </ul>

        <ul>
            <li><a href="#"> <b>ADMIN</b></a>
                <ul>
                    <li><a href="admin_insert.php">Add</a></li>
                    <li><a href="admin_list.php">List</a></li>
                </ul>
            </li>
        </ul>
                           
        <ul>
            <li><a href="#"> <b>STUDENT</b></a>
                <ul>
                    <li><a href="student_insert.php">Add</a></li>
                    <li><a href="student_menu.php">List</a></li>
                    <li><a href="student_search.php">Search</a></li>
                </ul>
            </li>
        </ul>
                          
        <ul>
            <li><a href="#"> <b>LECTURER</b></a>
                <ul>
                    <li><a href="lecturer_insert.php">Add</a></li>
                    <li><a href="lecturer_student_list.php">List</a></li>
                </ul>
            </li>
        </ul>
        <ul>
            <li><a href="#"> <b>SUPERVISOR</b></a>
                <ul>
                    <li><a href="supervisor_insert.php">Add</a></li>
                    <li><a href="supervisor_menu.php">List</a></li>
                </ul>
            </li>
        </ul>
                          
        <ul>
            <li><a href="#"> <b>OTHERS</b></a>
                <ul>
                    <li><a href="admin_home.php">Home</a></li>
                    <li><a href="welcome.php">Import</a></li>
                    <li><a href="report_print.php">Report</a></li>
                    <li><a href="login.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</div>
</body>
