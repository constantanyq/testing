<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$supervisor_id = $_POST["supervisor_id"];

		$sql = "delete from supervisor where supervisor_id = '$supervisor_id' ";
		$result=mysqli_query($conn, $sql);
		if ($result == true) {
			$record_count = mysqli_affected_rows($conn);
			if ($record_count > 0)
				echo "<br><center>Successfully deleted</center>";
			else
				echo "Tidak Successfully deleted. Rekod tidak ada dalam jadual";
			}
			else
				echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}
	
	if (isset($_GET['supervisor_id'])) 
		$supervisor_id = $_GET['supervisor_id'];
?>


<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<link rel="stylesheet" href="menu.css">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 95px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
</head>

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>

<h3 class="medium">DELETE SUPERVISOR</h3>
<form class="medium" action="supervisor_student_update_form.php" method="post">
	<table>
		<tr>
			<td>Supervisor ID</td>
			<td><input type="text" name="supervisor_id" value = "<?php echo $supervisor_id; ?>" ></td>
		</tr>
	</table>
	<button class="delete" type="submit" name="submit">Delete</button>
</form>
