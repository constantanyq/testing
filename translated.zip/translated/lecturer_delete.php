<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$lecturer_id = $_POST["lecturer_id"];

		$sql = "delete from lecturer where lecturer_id = '$lecturer_id' ";
		$result=mysqli_query($conn, $sql);
		if ($result == true) {
			$record_count = mysqli_affected_rows($conn);
			if ($record_count > 0)
				echo "<br><center>Successfully deleted</center>";
			else
				echo "Tidak Successfully deleted. Rekod tidak ada dalam jadual";
			}
			else
				echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}
	
	if (isset($_GET['lecturer_id'])) 
		$lecturer_id = $_GET['lecturer_id'];
?>


<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<link rel="stylesheet" href="menu.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>

<h3 class="medium">DELETE LECTURER</h3>
<form class="medium" action="lecturer_submit_marks.php" method="post">
	<table>
		<tr>
			<td>Lecturer ID</td>
			<td><input type="text" name="lecturer_id" value = "<?php echo $lecturer_id; ?>" ></td>
		</tr>
	</table>
	<button class="delete" type="submit" name="submit">Delete</button>
</form>
