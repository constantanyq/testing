<?php
	include("admin_menu.php");
	include("connection.php");
	
    if (isset($_POST["submit"])) {
		$admin_id = $_POST["admin_id"];
		$admin_name = $_POST["admin_name"];
		$password = $_POST["password"];

		$sql = "update admin set admin_name = '$admin_name', password='$password' where admin_id = '$admin_id' ";

		$result = mysqli_query($conn, $sql);
		if ($result == true)
			echo "<br><center>Successfully updated</center>";
		else
			echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}

    if (isset($_GET['admin_id'])) 
		$admin_id = $_GET['admin_id'];
	
	$sql = "select * from admin where admin_id = '$admin_id' ";
	$result = mysqli_query($conn, $sql);
	while($admin = mysqli_fetch_array($result)) {
		$password = $admin['password'];
		$admin_name = $admin['admin_name'];
	}
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<link rel="stylesheet" href="menu.css">

<h3 class="medium">UPDATE ADMIN</h3>

<form class="medium" action="admin_update.php" method="post">
<table>
	<tr>
	   
	       <td>Admin ID</td>
	       <td><input type="text" name="admin_id" value= "<?php echo $admin_id; ?>"
               placeholder="max: 3 char"></td>
	   
	</tr>
	<tr>
		<td>Admin Name</td>
		<td><input type="text" name="admin_name" value= "<?php echo $admin_name; ?>" ></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><input type="text" name="password" placeholder="max: 8 char" value= "<?php echo $password; ?>" ></td>
	</tr>
</table>
<button class="update" type="submit" name="submit">Update</button>
</form>
