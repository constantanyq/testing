<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$student_id = $_POST["student_id"];
		$password = $_POST["password"];
		$student_name = $_POST["student_name"];
        $email = $_POST["email"];
        $programme = $_POST["programme"];
        $lecturer_id = $_POST["lecturer_id"];
        $admin_id = $_POST["admin_id"];
        $supervisor_id = $_POST["supervisor_id"];

		$sql = "update student set password='$password', student_name = '$student_name', email = '$email', programme = '$programme', lecturer_id = '$lecturer_id', admin_id = '$admin_id', supervisor_id = '$supervisor_id' where student_id = '$student_id' ";

		$result = mysqli_query($conn, $sql);
		if ($result == true)
			echo "<br><center>Successfully updated</center>";
		else
			echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}

	if (isset($_GET['student_id']))
		$student_id = $_GET['student_id'];

	$sql = "select * from student where student_id = '$student_id' ";
	$result = mysqli_query($conn, $sql);
	while($student = mysqli_fetch_array($result)) {
		$password = $student['password'];
		$student_name = $student['student_name'];
        $email = $student['email'];
        $programme = $student['programme'];
        $lecturer_id = $student['lecturer_id'];
        $admin_id = $student['admin_id'];
        $supervisor_id = $student['supervisor_id'];
	}
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        button.update{
             background-image: url(imej/update.png);
             background-repeat: no-repeat;
             background-position: 6px;
        }
    </style>
</head>

<h3 class="medium">UPDATE STUDENT</h3>
<form class="medium" action="student_update_form.php" method="post">
	<table>
       <tr>
	       <td>Student ID</td>
	       <td><input type="text" name="student_id" value= "<?php echo $student_id; ?>"
               placeholder="max: 3 char"></td>
	   </tr>
	   <tr>
	       <td>Password</td>
	       <td><input type="password" name="password" value= "<?php echo $password; ?>"
               placeholder="max: 8 char"></td>
	   </tr>
		<tr>
			<td>Student Name</td>
			<td><input type="text" name="student_name" value= "<?php echo $student_name; ?>"></td>
		</tr>
        <tr>
			<td>Email</td>
             <td><input type="text" name="email" value= "<?php echo $email; ?>"></td>
		</tr>
        <tr>
			<td>Programme</td>
             <td><input type="text" name="programme" value= "<?php echo $programme; ?>"></td>
		</tr>
	   <tr>
	       <td>Lecturer ID</td>
	       <td><input type="text" name="lecturer_id"
               placeholder="max: 3 char" value= "<?php echo $lecturer_id; ?>" ></td>
	   </tr>
	   <tr>
	       <td>Admin ID</td>
	       <td><input type="text" name="admin_id"
               placeholder="max: 3 char" value= "<?php echo $admin_id; ?>" ></td>
	   </tr>
	   <tr>
	       <td>Supervisor ID</td>
	       <td><input type="text" name="supervisor_id"
               placeholder="max: 3 char" value= "<?php echo $supervisor_id; ?>" ></td>
	   </tr>
	</table>
	<button class="update" type="submit" name="submit">Update</button>
</form>
