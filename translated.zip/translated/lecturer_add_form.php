<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$lecturer_id = $_POST["lecturer_id"];
		$password = $_POST["password"];
		$lecturer_name = $_POST["lecturer_name"];
        $lecturer_email = $_POST["lecturer_email"];

		$sql = "insert into lecturer values('$lecturer_id', '$password', '$lecturer_name', '$lecturer_email')";

		$result = mysqli_query($conn, $sql);
		if ($result == true)
			echo "<br><center>Successfully added</center>";
		else
			echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
	}
?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">

<h3 class="medium">ADD LECTURER</h3>
<form class="medium" action="lecturer_insert.php" method="post">
	<table>
       <tr>
	       <td>Lecturer ID</td>
	       <td><input type="text" name="lecturer_id" 
               placeholder="max: 3 char"></td>
	   </tr>
		<tr>
			<td>Lecturer Name</td>
			<td><input type="text" name="lecturer_name"></td>
		</tr>
        <tr>
	       <td>Password</td>
	       <td><input type="password" name="password" 
               placeholder="max: 8 char"></td>
	   </tr>
        <tr>
			<td>Lecturer Email</td>
             <td><input type="text" name="lecturer_email">
	</table>
        <button class="add" type="submit" name="submit">Add</button>
</form>

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        
        button.add{
             background-image: url(imej/add.png);
             background-repeat: no-repeat;
             background-position: 6px ;

        }
    </style>
</head>

    
<center>
	<button class="blue" onclick="change_colour(0)">Biru</button>
	<button class="green" onclick="change_colour(1)">Hijau</button>
	<button class="red" onclick="change_colour(2)">Merah</button>
	<button class="black" onclick="change_colour(3)">Hitam</button>
</center>

<script>
	function change_colour(n){
		var colours = ["Blue", "Green", "Red", "Black"];
		var teks = document.getElementsByClassName("colour");
		for(var i=0; i<teks.length; i++)
			teks[i].style.color=colours[n];
	}
</script>

