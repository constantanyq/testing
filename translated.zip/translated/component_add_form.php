<?php
    include("admin_menu.php");
    include("connection.php");
    if (isset($_POST["submit"])) {
        $component_id = $_POST["component_id"];
        $component_name = $_POST["component_name"];
        $component_weightage = $_POST["component_weightage"];
        $sql = "insert into component values('$component_id', '$component_name', '$component_weightage')";
        $result = mysqli_query($conn, $sql);
        if ($result == true)
            echo "<br><center>Successfully added</center>";
        else
            echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
    }
?>
<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<h3 class="medium">ADD COMPONENT</h3>
<form class="medium" action="component_delete.php" method="post">
    <table>
        <tr>
            <td>Component ID</td>
            <td><input type="text" name="component_id"></td>
        </tr>
        <tr>
            <td>Component Name</td>
            <td><input type="text" name="component_name"></td>
        </tr>
        <tr>
            <td>Weightage</td>
            <td><input type="text" name="component_weightage"></td>
        </tr>
    </table>
<button class="add" type="submit" name="submit">Add</button>
</form>


<center>
	<button class="blue" onclick="change_colour(0)">Biru</button>
	<button class="green" onclick="change_colour(1)">Hijau</button>
	<button class="red" onclick="change_colour(2)">Merah</button>
	<button class="black" onclick="change_colour(3)">Hitam</button>
</center>

<script>
	function change_colour(n){
		var colours = ["Blue", "Green", "Red", "Black"];
		var teks = document.getElementsByClassName("colour");
		for(var i=0; i<teks.length; i++)
			teks[i].style.color=colours[n];
	}
</script>

