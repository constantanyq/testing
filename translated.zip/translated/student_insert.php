<?php
include("student_marks.php");
include("lecturer_update_form.php"); 
?>
