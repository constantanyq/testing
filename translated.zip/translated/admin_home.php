<?php
    include("admin_menu.php");
    include("lecturer_update_form.php");
?>
