<?php
      session_start();
      include("supervisor_add_form.php");
      include("connection.php");
?>

<html>
<link rel="stylesheet" href="senarai.css">
<link rel="stylesheet" href="button.css">
    <link rel="stylesheet" href="menu.css">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 120px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
</head>

<body>
<table>
<caption>STUDENT LIST BY SUPERVISOR</caption>

<?php
      $name = $_SESSION["nama"];
      $supervisor_id = $_SESSION['user_id'];

      $header = " <tr> <th>No.</th>
                                <th>Name</th>";

      $sql = "select * from student order by student_id asc";

      $data = mysqli_query($conn, $sql);
      while ($component = mysqli_fetch_array($data)) {
            $header = $header."<th>".$component['component_name']."</th>";
      }
      $header = $header."<th>Total</th></tr>";

      echo $header;
      $count = 1;
      $sql = "select * from supervisor
      join student on supervisor.student_id = student.student_id join component on result.component_id = component.component_id where supervisor.supervisor_id = '$supervisor_id'
      order by result.total_marks desc, component.component_id asc   ";

      $data = mysqli_query($conn, $sql);
      $a = 1;
      $count = 1;
      while ($student_row = mysqli_fetch_array($data)) {
            if ($a == 1)
                  echo "<tr>
                  <td>".$count."</td>
                  <td>".$result['student_name']."</td>";

            if ($a < 6)
                  echo "<td>".$result['component_marks']."</td>";

            $a = $a + 1;
                        if ($a == 6) {
                 echo "<td>".$result['total_marks']."</td>
                             </tr>";
                 $a = 1;
                 $count = $count + 1;
            }   
      } // end while    
?>
</table>
</body>
</html>