<?php
	include("admin_menu.php");
    include("connection.php");
?>

<link rel="stylesheet" href="senarai.css">
<link rel="stylesheet" href="borang.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>
<table>
	<caption>LECTURER LIST</caption>
	<tr>
		<th>ID</th>
		<th>Name</th>		
		<th>Password</th>
        <th>Kategori</th>
		<th colspan="2">Action</th>
	</tr>

<?php
	$sql = "select * from lecturer";
	$result = mysqli_query($conn, $sql);
	while($lecturer = mysqli_fetch_array($result)) {
		echo "<tr>
			<td>$lecturer[lecturer_id]</td>
			<td>$lecturer[lecturer_name]</td>
			<td>$lecturer[password]</td>
            <td>$lecturer[lecturer_email]</td>
			<td><a href='lecturer_update_form.php?lecturer_id=$lecturer[lecturer_id]'>update</a></td>
			<td><a href='lecturer_delete.php?lecturer_id=$lecturer[lecturer_id]'>delete</a></td>
		</tr>";
}
?>
</table>
