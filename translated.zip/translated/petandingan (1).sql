-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2022 at 03:44 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petandingan`
--

-- --------------------------------------------------------

--
-- Table structure for table `supervisor`
--

CREATE TABLE `supervisor` (
  `supervisor_id` varchar(3) NOT NULL,
  `supervisor_name` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `supervisor_email` varchar(10) NOT NULL,
  `programme` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supervisor`
--

INSERT INTO `supervisor` (`supervisor_id`, `supervisor_name`, `password`, `supervisor_email`, `programme`) VALUES
('G01', 'Shim Shai', 'gdst', 'Rendah', 'SJK (C) KEPONG 3'),
('G02', 'Suraya', 'math', 'Menengah', 'SMK Taman Bukit Maluri'),
('G03', 'IU Li', 'blueming', 'Menengah', 'SMK Jalan Ipoh'),
('G04', 'Ipini', 'upin', 'Rendah', 'SK Selayang Baru'),
('G05', 'Doha', 'mature', 'Menengah', 'SMK Taman Bukit Maluri'),
('G06', 'Taehyung', 'head', 'Rendah', 'SJK(C)Kai Chee'),
('G07', 'Scratch Cat', 'code', 'Menengah', 'SMK Jalan Ipoh');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lecturer_id` varchar(3) NOT NULL,
  `password` varchar(8) NOT NULL,
  `lecturer_name` varchar(30) NOT NULL,
  `lecturer_email` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`lecturer_id`, `password`, `lecturer_name`, `lecturer_email`) VALUES
('H01', 'abualia3', 'Joshua', 'Menengah'),
('H02', 'baixuesn', 'Snowei', 'Menengah'),
('H03', 'jieling', 'Jie Lin', 'Menengah'),
('H04', '30days', 'Gyubin', 'Menengah'),
('H05', 'abcd', 'qqwechat', 'Rendah'),
('H06', 'Adnan', 'leftenan', 'Rendah'),
('H07', 'Yin luo', 'fuheng', 'Rendah');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `student_id` varchar(12) NOT NULL,
  `component_id` varchar(3) NOT NULL,
  `component_marks` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`student_id`, `component_id`, `component_marks`, `total_marks`) VALUES
('P01', 'M01', 18, 72),
('P01', 'M02', 18, 72),
('P01', 'M03', 18, 72),
('P01', 'M04', 18, 72),
('P02', 'M01', 13, 73),
('P02', 'M02', 16, 73),
('P02', 'M03', 20, 73),
('P02', 'M04', 24, 73),
('P03', 'M01', 24, 91),
('P03', 'M02', 23, 91),
('P03', 'M03', 24, 91),
('P03', 'M04', 20, 91),
('P04', 'M01', 25, 96),
('P04', 'M02', 24, 96),
('P04', 'M03', 25, 96),
('P04', 'M04', 22, 96),
('P05', 'M01', 18, 74),
('P05', 'M02', 19, 74),
('P05', 'M03', 20, 74),
('P05', 'M04', 17, 74),
('P06', 'M01', 24, 93),
('P06', 'M02', 25, 93),
('P06', 'M03', 21, 93),
('P06', 'M04', 23, 93),
('P07', 'M01', 15, 67),
('P07', 'M02', 18, 67),
('P07', 'M03', 24, 67),
('P07', 'M04', 10, 67),
('P08', 'M01', 23, 91),
('P08', 'M02', 23, 91),
('P08', 'M03', 22, 91),
('P08', 'M04', 23, 91),
('P09', 'M01', 21, 81),
('P09', 'M02', 21, 81),
('P09', 'M03', 18, 81),
('P09', 'M04', 21, 81),
('P10', 'M01', 22, 88),
('P10', 'M02', 22, 88),
('P10', 'M03', 22, 88),
('P10', 'M04', 22, 88),
('P14', 'M01', 23, 83),
('P14', 'M02', 20, 83),
('P14', 'M03', 20, 83),
('P14', 'M04', 20, 83),
('P16', 'M01', 1, 65),
('P16', 'M02', 14, 65),
('P16', 'M03', 25, 65),
('P16', 'M04', 25, 65);

-- --------------------------------------------------------

--
-- Table structure for table `component`
--

CREATE TABLE `component` (
  `component_id` varchar(3) NOT NULL,
  `component_name` varchar(30) NOT NULL,
  `component_weightage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `component`
--

INSERT INTO `component` (`component_id`, `component_name`, `component_weightage`) VALUES
('M01', 'Matematik', 25),
('M02', 'Sains', 25),
('M03', 'Fizik', 25),
('M04', 'Kimia', 25);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` varchar(12) NOT NULL,
  `password` varchar(8) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `programme` varchar(100) NOT NULL,
  `lecturer_id` varchar(3) NOT NULL,
  `admin_id` varchar(3) NOT NULL,
  `supervisor_id` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `password`, `student_name`, `email`, `programme`, `lecturer_id`, `admin_id`, `supervisor_id`) VALUES
('P', '1', '', '12', '23', 'H01', 'U01', 'G01'),
('P01', 'abu', 'Abu Bakar Mohemed Salleh', 'bakarsendiri@gmail.com', 'SMK Raja Ali', 'H03', 'U01', 'G01'),
('P02', 'blueming', 'IU', 'uaena@gmail.com', 'SMK St.Mary', 'H02', 'U03', 'G01'),
('P03', 'etyw', 'yeonwoo ha', 'yeonwoo@gmail.com', 'SMK Jalan Ipoh', 'H04', 'U05', 'G03'),
('P04', 'stella', 'euntae cha', 'euntaes@gmail.com', 'SMK St.John', 'H05', 'U05', 'G02'),
('P05', 'annabeh', 'Anna', 'annabelle@gmail.com', 'SMK Taman Bukit Maluri', 'H01', 'U01', 'G02'),
('P06', 'sarangha', 'Eunwoo Cha', 'eunwoistyq@gmail.com', 'SMK Sinar Bintang', 'H01', 'U01', 'G01'),
('P07', 'dontstea', 'Lia Wo', 'etisywnotlia@gmail.com', 'SMK St.Mary', 'H02', 'U04', 'G03'),
('P08', 'chunsung', 'Sooyoung', 'cafemeet@gmail.com', 'SMK St.Mary', 'H04', 'U05', 'G03'),
('P09', 'yong', 'carmen', 'yongcarmen@gmail.com', 'SJK (C) Kepong 3', 'H03', 'U02', 'G04'),
('P1', '54', '123', '123@gmail.com', 'SMK Taman Bukit Maluri', 'H01', 'U01', 'G01'),
('P10', 'dioran', 'Yap Xin Ran', 'xinranyp@gmail.com', 'SJK (C) Kai Chee', 'H03', 'U02', 'G04'),
('P11', 'sukiii', 'Suki', 'ratsuki@gmail.com', 'SMK Sinar Bintang', 'H03', 'U03', 'G03'),
('P12', 'aoi', 'Aoi Chan', 'naily@gmail.com', 'SMJK Chong Hwa', 'H04', 'U04', 'G02'),
('P13', 'muthu', 'Muthu', 'muthu@gmail.com', 'SMK Jlan Ipoh', 'H01', 'U01', 'G01'),
('P14', '1414', 'shi si', 'tentyfour@gmail.com', 'SMK DUA', 'H02', 'U01', 'G01'),
('P15', 'shuip', 'Kung Fu', 'kungfupanda@gmail.com', 'SMK CHINA KUNG FU', 'H04', 'U03', 'G03'),
('P16', '1234', '1', '1', '1', 'H01', 'U01', 'G01'),
('P18', 'abu', 'Ali', 'ali@gmail.com', 'SMK Raja Ali', 'H01', 'U01', 'G01'),
('P20', 'abubakar', 'Bakar Avu', 'avuvuevue@gmail.com', 'SMK ST.MARY', 'H02', 'U01', 'G03'),
('P21', 'nailyheh', 'Naily', 'nailychan@gmail.com', 'SMK ST.MARY', 'H02', 'U01', 'G03');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` varchar(3) NOT NULL,
  `password` varchar(8) NOT NULL,
  `admin_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `password`, `admin_name`) VALUES
('U01', 'ahkiqing', 'Ying Qi'),
('U02', 'ahshuan', 'Yin Xuen'),
('U03', '12345', 'Isaac'),
('U04', 'avuvu', 'Abu Bakar'),
('U05', 'happy', 'Jooyul');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `supervisor`
--
ALTER TABLE `supervisor`
  ADD PRIMARY KEY (`supervisor_id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`lecturer_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`student_id`,`component_id`) USING BTREE,
  ADD KEY `component_id` (`component_id`),
  ADD KEY `student_id` (`student_id`) USING BTREE;

--
-- Indexes for table `component`
--
ALTER TABLE `component`
  ADD PRIMARY KEY (`component_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `lecturer_id` (`lecturer_id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `supervisor_id` (`supervisor_id`) USING BTREE;

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_penilaian` FOREIGN KEY (`component_id`) REFERENCES `component` (`component_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `result_peserta` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `peserta_guru` FOREIGN KEY (`supervisor_id`) REFERENCES `supervisor` (`supervisor_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `peserta_hakim` FOREIGN KEY (`lecturer_id`) REFERENCES `lecturer` (`lecturer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `peserta_urusetia` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
