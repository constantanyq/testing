<?php
	include("supervisor_add_form.php");
    include("connection.php");
?>

<link rel="stylesheet" href="senarai.css">
<link rel="stylesheet" href="borang.css">

<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>
<table>
	<caption>SUPERVISOR LIST</caption>
	<tr>
		<th>ID</th>
		<th>Name</th>		
        <th>Programme</th>
        <th>Kategori</th>
	</tr>

<?php
	$sql = "select * from supervisor";
	$result = mysqli_query($conn, $sql);
	while($supervisor = mysqli_fetch_array($result)) {
		echo "<tr>
			<td>$supervisor[supervisor_id]</td>
			<td>$supervisor[supervisor_name]</td>
            <td>$supervisor[programme]</td>
            <td>$supervisor[supervisor_email]</td>
		</tr>";
}
?>
</table>