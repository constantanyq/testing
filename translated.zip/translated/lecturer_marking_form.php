<?php
	session_start();
	include("lecturer_add_form.php");
    include("connection.php");
	$name = $_SESSION["nama"];
	$lecturer_id = $_SESSION["user_id"];
?>
<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<link rel="stylesheet" href="menu.css">

<head>
<body>
    <style>
    ul li a {
	font-family: verdana;
	font-size: 14px;
	font-weight: normal;
	text-align: center;
        color: black;

	width: 120px;
    padding: 9px;
    border: 1px dotted darkblue;
    margin: 0px;
        background-color: gainsboro;
    padding-bottom: 10px;

	display: block;
	text-decoration:none;
              }
    </style>
</body>
</head>

<div class="content">
	<h3 class="marks">MARKING FORM</h3>
	<form class="marks" action="lecturer_marking_form.php" method="post">
	<table>
		<tr>
			<td>Lecturer Name : </td>
			<td><?php echo $name; ?> </td>
		</tr>

		<tr>
			<td>Student: </td>
			<td>
				<select class="marks" name="student_id">
				<?php
					$sql = "select * from student where lecturer_id='$lecturer_id' ";
					$data = mysqli_query($conn, $sql);
					while ($student = mysqli_fetch_array($data)) {
						echo "<option value='$student[student_id]'>$student[student_name]</option>";
					}
				?>
				</select>
			</td>
		</tr>
</table>

<table class="marks">
	<tr>
		<th>Component Name</th>
		<th>Weightage</th>
		<th>Marks Obtained</th>
	</tr>
	<?php
		$sql = "select * from component";
		$data = mysqli_query($conn, $sql);
		while ($component = mysqli_fetch_array($data)) {
		echo "<tr >
			<td>$component[component_name]</td>
			<td>$component[component_weightage]</td>
			<td><input oninput='kira_jumlah()' class='marks' type='text' id='$component[component_id]' name='$component[component_id]' value=0></td>
		          </tr>";
		} 
	?>

	<tr class="marks_total">
		<td></td>
		<td class="marks_total">Total Marks</td>
		<td><input class="marks" type="text" id="total_marks" name="total_marks"></td>
	</tr>
	</table>
	<button class="add" type="submit" name="submit">Add</button>
	</form>
</div>
<script type="text/javascript">
	function kira_jumlah() {
		var jum_semua = 0;

		<?php
			$sql = "select * from component";
			$data = mysqli_query($conn, $sql);
			while ($component = mysqli_fetch_array($data)) {	
				echo "var component_marks = parseInt(document.getElementById('$component[component_id]').value);
					jum_semua = jum_semua + component_marks;";
			} // end while
		?>
		document.getElementById("total_marks").value = jum_semua;
	} 
</script>
