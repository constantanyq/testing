<?php
	include("admin_menu.php");
    include("connection.php");

	if (isset($_POST["submit"])) {
		$student_id = $_POST["student_id"];

	$sql = "delete from student where student_id = '$student_id'
";
	$result = mysqli_query($conn, $sql);
	if ($result == true) {
		$record_count = mysqli_affected_rows($conn);
		if ($record_count > 0)
			echo "<br><center>Successfully deleted</center>";
		else
			echo "Tidak Successfully deleted. Rekod tidak ada dalam jadual";
}


	else
		echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
}
if (isset($_GET['student_id']))
		$student_id = $_GET['student_id'];

?>

<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">

<h3 class="medium">DELETE STUDENT</h3>
<form class="medium" action="student_info.php" method="post">
<table>
<tr>
		<td>Student ID</td>
		<td><input type="text" name="student_id" value = "<?php echo $student_id; ?>" ></td>
</tr>
</table>
<button class="delete" type="submit" name="submit">Delete</button>
</form>
