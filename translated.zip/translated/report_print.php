<html>
    <link rel="stylesheet" href="senarai.css">
    <link rel="stylesheet" href="button.css">
    <body>
        <table>
            <?php
                include("admin_menu.php");
                include("connection.php");

                $choice = $_POST["pilihan"];
                $header = " <tr>
                           <th>No.</th>
                           <th>Name</th>";

                $sql = "select * from component order by component_id asc";
                $data = mysqli_query($conn, $sql);
                while ($component = mysqli_fetch_array($data)) {
                    $header = $header."<th>".$component['component_name']."</th>";
                }
                $header = $header."<th>Total</th></tr>";
//pemilihan laporan jenis keseluruhan atau mengikut lecturer, jika mengikut lecturer, fetch data daripada jadual lecturer untuk memaparkan component_marks-component_marks yang telah diinputkan
                switch ($choice) {
                    case 1 : $condition = " ";
                        $title = " <caption>OVERALL MARKS LIST</caption> ";
                        break;
                    case 2 : $lecturer_id = $_POST["lecturer_id"];
                        $condition = "where lecturer.lecturer_id = '$lecturer_id' "; 
                        $title = " <caption>STUDENT LIST BY LECTURER</caption> ";
                        break;
                }
                echo $header;
                $count = 1;
                $sql = "select * from result join student on result.student_id = student.student_id 
                        join component on result.component_id = component.component_id
                        join lecturer on student.lecturer_id = lecturer.lecturer_id $condition
                        order by result.total_marks desc, component.component_id asc";

                $data = mysqli_query($conn, $sql);
                $a = 1;
                $count = 1;

                while ($result = mysqli_fetch_array($data)) {
                    if ($a == 1)
                        echo "<tr>
                            <td>".$count."</td>
                            <td class='name'>".$result['student_name']."</td>";
                    if ($a < 5)
                        echo "<td>".$result['component_marks']."</td>";

                    $a = $a + 1;
                    if ($a == 5) {
                        echo "<td>".$result['total_marks']."</td>    </tr>";
                        $a = 1;
                        $count = $count + 1;
                    } 
                } // end while
            ?>
        <caption><?php echo $title; ?> </caption>
        </table>
        <center><button class="print" onclick="window.print()">Print</button></center>
</body>
</html>
