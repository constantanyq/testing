<?php
    include("admin_menu.php");
    include('connection.php');

    if (isset($_POST["submit"])) {
        $table_name = $_POST['namatable'];
        $filename = $_FILES['namafail']['name'];

        $temp_file = $_FILES['namafail']['tmp_name'];
        move_uploaded_file($temp_file, $filename);

        $file = fopen($filename, "r");
        while (!feof($file)) {
            $fields = explode(",", fgets($file));
            
            $success = false;
            
            /*menentukan data yang perlu dimasukkan mengikut urutan*/
            if (strtolower($table_name) === "student") {
                /*pengguna memilih kategori student*/
                $student_id = $fields[0];
                $password = $fields[1];
                $student_name = $fields[2];
                $email = $fields[3];
                $programme = $fields[4];
                $lecturer_id = $fields[5];
                $admin_id = $fields[6];
                $supervisor_id = trim($fields[7]);

                $sql = "insert into student values('$student_id', '$password', '$student_name', '$email', '$programme', '$lecturer_id', '$admin_id', '$supervisor_id')";

                if (mysqli_query($conn, $sql))
                    $success = true;
                else
                    echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
            } 
        if (strtolower($table_name) === "lecturer") {
         /*pengguna memilih kategori lecturer*/
            $lecturer_id = $fields[0];
            $lecturer_name = $fields[1];
            $password = $fields[2];
            $lecturer_email = trim($fields[3]);
            $sql = "insert into lecturer values('$lecturer_id', '$lecturer_name','$password', '$lecturer_email')"; 
            
            if (mysqli_query($conn, $sql))
                $success = true;
            else
                echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
        }
        if (strtolower($table_name) === "supervisor") {
         //pengguna memilih kategori supervisor
            $supervisor_id = $fields[0];
            $supervisor_name = $fields[1];
            $password = $fields[2];
            $supervisor_email = $fields[3];
            $programme = trim($fields[4]);
            
            $sql = "insert into supervisor values('$supervisor_id', '$supervisor_name','$password', '$supervisor_email', '$programme')"; 
            
            if (mysqli_query($conn, $sql))
                $success = true;
            else
                echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
             
        }
}
        //mesej loclhost
        if ($success == true)
            echo "<script>alert('Records imported successfully');</script>";
        else
            echo "<script>alert('Failed to import records');</script>";
        mysqli_close($conn);
    }
?>

<html>
    <link rel="stylesheet" href="borang.css">
    <link rel="stylesheet" href="button.css">
<head>
    <style>
        body {
            background-image: url(imej/wood8.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
</head>
    <body>
        <h3 class="medium">IMPORT DATA</h3>
        <form class="medium" action="welcome.php" method="post"
                enctype = "multipart/form-data" class="import">

            <table>
                <tr>
                    <td>Table</td>
                    <td>
                        <!Scroll down menu bagi memilih jenis jadual yang akan diimport>
                        <select name="table_name">
                            <option>Peserta</option>
                            <option>Hakim</option>
                            <option>Guru</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>Name fail</td>
                    <td><input type="file" name="filename" accept=".txt"></td>
                </tr>
            </table>
            <!butang-butang>
            <button class="import" type="submit" name="submit">Import</button>
        </form>
    </body>
</html>
