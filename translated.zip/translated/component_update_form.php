<?php
    include("admin_menu.php");
    include("connection.php");

    if (isset($_POST["submit"])) {
        $component_id = $_POST["component_id"];
        $component_name = $_POST["component_name"];
        $component_weightage = $_POST["component_weightage"];
        $sql = "update component set component_name = '$component_name', component_weightage = '$component_weightage' where component_id = '$component_id' "; 
        $result = mysqli_query($conn, $sql);
        if ($result == true)
            echo "<br><center>Successfully updated</center>";
        else
            echo "<br><center>Error: $sql<br>".mysqli_error($conn)."</center>";
    }
    if (isset($_GET['component_id']))
        $component_id = $_GET['component_id'];
    $sql = "select * from component where component_id = '$component_id' ";
    $result = mysqli_query($conn, $sql);
    while($component = mysqli_fetch_array($result)) {
        $component_name = $component['component_name'];
        $component_weightage = $component['component_weightage'];
    }
?>
<link rel="stylesheet" href="borang.css">
<link rel="stylesheet" href="button.css">
<h3 class="medium">UPDATE COMPONENT</h3>
<form class="medium" action="component_list.php" method="post">
<table>
    <tr>
        <td>Component ID</td>
        <td><input type="text" name="component_id" value= "<?php echo $component_id; ?>"></td>
    </tr>
    <tr>
        <td>Component Name</td>
        <td><input type="text" name="component_name" value= "<?php echo $component_name; ?>"></td>
    </tr>
    <tr>
        <td>Weightage</td>
        <td><input type="text" name="component_weightage" value= "<?php echo $component_weightage; ?>"></td>
    </tr>
    </table>
<button class="update" type="submit" name="submit">Update</button>
</form>
