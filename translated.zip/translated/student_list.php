<?php
	include("admin_menu.php");
    include("connection.php");
?>

<link rel="stylesheet" href="senarai.css">
<link rel="stylesheet" href="menu.css">
<link rel="stylesheet" href="borang.css">

<table>
<caption>STUDENT LIST</caption>
<tr>
<th>Student ID</th>
<th>Student Name</th>
<th>Password</th>
<th>Email</th>
<th>Programme</th>
<th>Lecturer ID</th>
<th>Supervisor ID</th>
<th colspan="2">Action</th>
</tr>

<?php
$sql = "select * from student";
$result = mysqli_query($conn, $sql);
while($student = mysqli_fetch_array($result)) {
echo "<tr> 
<td>$student[student_id]</td>
<td class='name'>$student[student_name]</td>
<td>$student[password]</td>
<td>$student[email]</td>
<td>$student[programme]</td>
<td>$student[lecturer_id]</td>
<td>$student[supervisor_id]</td>
<td><a href='student_update_form.php?student_id=$student[student_id]'>update</a></td>
<td><a href='student_delete.php?student_id=$student[student_id]'>delete</a></td>
</tr>";
}
?>
</table>
